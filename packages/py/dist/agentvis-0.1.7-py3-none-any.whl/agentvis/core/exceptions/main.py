class ToolMessagesMismatchException(Exception):
    def __init__(self, message: str):
        self.message = message
        super().__init__(self.message)

class MissingToolMessagesException(Exception):
    def __init__(self, message: str):
        self.message = message
        super().__init__(self.message)